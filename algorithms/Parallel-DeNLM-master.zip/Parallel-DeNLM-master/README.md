# Parallel-DeNLM

Parallel implementation of Deceived Non Local Means filter using openmp.
